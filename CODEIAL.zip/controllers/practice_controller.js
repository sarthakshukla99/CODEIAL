module.exports.practice = function(req,res){
    res.end('<h1>NEW PRACTICE PAGE</h1>');
}